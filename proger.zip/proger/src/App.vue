<script setup>
import backend from './components/backend.php';
import Request from './components/Request.php';
import axios from 'axios';
</script>

<template>
  <form @submit.prevent="submitForm">
    <div>
      <label>Имя:</label>
      <input type="text" v-model="name">
    </div>
    <div>
      <label>Email:</label>
      <input type="email" v-model="email">
    </div>
    <div>
      <label>Телефон:</label>
      <input type="text" v-model="phone">
    </div>
    <div>
      <label>Цена:</label>
      <input type="number" v-model="price">
    </div>
    <button type="submit">Отправить</button>
  </form>
</template>

<script>


export default {
  data() {
    return {
      name: '',
      email: '',
      phone: '',
      price: null
    }
  },
  methods: {
    async submitForm() {
      const formData = {
        name: this.name,
        email: this.email,
        phone: this.phone,
        price: this.price
      };
      
      try {
        const response = await axios.post('/api/send-form', formData);
        console.log(response.data);
      } catch (error) {
        console.log(error);
      }
    }
  }
}

</script>

