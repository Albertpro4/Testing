<? php 

class AmoCRM {
  private $client_id;
  private $client_secret;
  private $redirect_uri;
  private $access_token;

  public function __construct($client_id, $client_secret, $redirect_uri) {
    $this->client_id = $client_id;
    $this->client_secret = $client_secret;
    $this->redirect_uri = $redirect_uri;
  }


  private function request($url, $params = array(), $method = 'GET') {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'amoCRM-API-client/1.0');
    curl_setopt($ch, CURLOPT_URL, $url);

    if ($method == 'POST') {
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    }
  
    if ($method == 'PATCH') {
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'Authorization: Bearer ' . $this->access_token
    ));

    $result = curl_exec($ch);

    curl_close($ch);

    return json_decode($result, true);
  }

  private function authorize($code) {
    $params = array(
      'client_id' => $this->client_id,
      'client_secret' => $this->client_secret,
      'grant_type' => 'authorization_code',
      'code' => $code,
      'redirect_uri' => $this->redirect_uri
    );

    $result = $this->request('https://oauth2.amocrm.ru/access_token', $params, 'POST');

    if (isset($result['access_token'])) {
      $this->access_token = $result['access_token'];
      return true;
    }

    return false;
  }

  public function auth($code) {
    return $this->authorize($code);
  }

  public function createContact($name, $email, $phone) {
    $params = array(
      'add' => array(
        array(
          'name' => $name,
          'custom_fields' => array(
            array(
              'id' => 123456, // ID поля "Email"
              'values' => array(
                array(
                  'value' => $email,
                  'enum' => 'WORK'
                )
              )
            ),
            array(
              'id' => 123457, // ID поля "Телефон"
              'values' => array(
                array(
                  'value' => $phone,
                  'enum' => 'WORK'
                )
              )
            )
          )
        )
      )
    );

    $result = $this->request('https://api.amocrm.ru/v4/contacts', $params, 'POST');
  }
  
}



    public function createDeal($contact_id, $price) {
        $params = array(
        'add' => array(
        array(
        'name' => 'Заявка с сайта',
        'contacts_id' => array($contact_id),
        'price' => $price,
        'pipeline_id' => 123456, // ID воронки, к которой привязана сделка
        'status_id' => 123457 // ID статуса, в который нужно переместить сделку
        )
        )
        );
        $result = $this->request('https://api.amocrm.ru/v4/leads', $params, 'POST');

        return isset($result['_embedded']['leads'][0]['id']) ? $result['_embedded']['leads'][0]['id'] : false;
    }        



    ?>
