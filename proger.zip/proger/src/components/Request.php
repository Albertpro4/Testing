<?php 


// обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $form = new Form($_POST['name'], $_POST['email'], $_POST['phone'], $_POST['price']);
    if ($form->validate()) {
        $amo = new AmoCRM($client_id, $client_secret, $redirect_uri);
        $amo->auth($code);
        $contact_id = $amo->createContact($form->getName(), $form->getEmail(), $form->getPhone());
        $amo->createDeal($contact_id, $form->getPrice());
        // вывод сообщения об успешной отправке заявки
    }
    
}

    ?>



